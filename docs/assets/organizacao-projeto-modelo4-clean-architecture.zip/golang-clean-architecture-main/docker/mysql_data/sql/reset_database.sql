DROP DATABASE IF EXISTS golang_clean_architecture;
CREATE DATABASE golang_clean_architecture CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
