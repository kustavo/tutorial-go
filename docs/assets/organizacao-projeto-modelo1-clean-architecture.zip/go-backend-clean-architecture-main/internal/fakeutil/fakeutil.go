package fakeutil
